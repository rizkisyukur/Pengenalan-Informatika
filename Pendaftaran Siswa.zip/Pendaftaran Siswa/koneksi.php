<?php 
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "db_vsga";

    //koneksi
    $koneksi = mysqli_connect($host, $user, $password, $database);
?>