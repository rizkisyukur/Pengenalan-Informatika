<?php 
include 'koneksi.php';

$id             = $_POST['id_siswa'];
$nama           = $_POST['nama'];
$alamat         = $_POST['alamat'];
$jenis_kelamin  = $_POST['jenis_kelamin'];
$agama          = $_POST['agama'];
$sekolah        = $_POST['sekolah'];
 
$query1 = "UPDATE siswa SET nama='$nama', alamat='$alamat', jenis_kelamin='$jenis_kelamin', 
        agama='$agama', sekolah='$sekolah' WHERE id_siswa='$id'";

mysqli_query($koneksi, $query1);

header("location:index.php?pesan=update");
?>