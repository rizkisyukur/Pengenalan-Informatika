<?php
include 'koneksi.php';

$nama           = $_POST['nama'];
$alamat         = $_POST['alamat'];
$jenis_kelamin  = $_POST['jenis_kelamin'];
$agama          = $_POST['agama'];
$sekolah        = $_POST['sekolah'];

$query="INSERT INTO siswa SET nama='$nama', alamat='$alamat',
        jenis_kelamin='$jenis_kelamin', agama='$agama', sekolah='$sekolah'";
mysqli_query($koneksi, $query);
header('location:index.php?pesan=input');
?>